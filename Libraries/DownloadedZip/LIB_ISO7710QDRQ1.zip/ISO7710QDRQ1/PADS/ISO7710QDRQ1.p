*PADS-LIBRARY-PART-TYPES-V9*

ISO7710QDRQ1 SOIC127P600X175-8N I ANA 7 1 0 0 0
TIMESTAMP 2026.09.04.08.40.06
"Mouser Part Number" 595-ISO7710QDRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ISO7710QDRQ1?qs=5aG0NVq1C4x4UnR4pgC%252BeQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ISO7710QDRQ1
"Description" Automotive, High Speed, Robust EMC Reinforced Single-Channel Digital Isolator
"Datasheet Link" http://www.ti.com/lit/gpn/iso7710-q1
"Geometry.Height" 1.75mm
GATE 1 8 0
ISO7710QDRQ1
1 0 U VCC1_1
2 0 U IN
3 0 U VCC1_2
4 0 U GND1
8 0 U VCC2
7 0 U NC
6 0 U OUT
5 0 U GND2

*END*
*REMARK* SamacSys ECAD Model
788190/1869991/2.50/8/3/Integrated Circuit
