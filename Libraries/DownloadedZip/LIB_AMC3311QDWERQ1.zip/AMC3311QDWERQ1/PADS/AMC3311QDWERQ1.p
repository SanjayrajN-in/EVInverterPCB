*PADS-LIBRARY-PART-TYPES-V9*

AMC3311QDWERQ1 SOIC127P1030X265-16N I ANA 7 1 0 0 0
TIMESTAMP 2026.09.07.12.22.24
"Mouser Part Number" 595-AMC3311QDWERQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/AMC3311QDWERQ1?qs=HoCaDK9Nz5fMsJCBiktH8Q%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" AMC3311QDWERQ1
"Description" Operational Amplifiers - Op Amps Automotive, 0 to 2-V input, precision reinforced isolated amplifier with integrated DC/DC converter 16-SOIC -40 to 125
"Datasheet Link" https://www.ti.com/lit/ds/symlink/amc3311-q1.pdf?ts=1702017864365&ref_url=https%253A%252F%252Fwww.ti.com%252Fproduct%252FAMC3311-Q1%252Fpart-details%252FAMC3311QDWERQ1%253FkeyMatch%253DAMC3311QDWERQ1%2526tisearch%253Dsearch-everything%2526usecase%253DOPN
"Geometry.Height" 2.65mm
GATE 1 16 0
AMC3311QDWERQ1
1 0 U DCDC_OUT
2 0 U DCDC_HGND
3 0 U HLDO_IN
4 0 U NC
5 0 U HLDO_OUT
6 0 U IN
7 0 U HGND_1
8 0 U HGND_2
16 0 U DCDC_IN
15 0 U DCDC_GND
14 0 U DIAG
13 0 U LDO_OUT
12 0 U VDD
11 0 U OUTP
10 0 U OUTN
9 0 U GND

*END*
*REMARK* SamacSys ECAD Model
18899970/1869991/2.50/16/3/Integrated Circuit
