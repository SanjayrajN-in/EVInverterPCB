*PADS-LIBRARY-PART-TYPES-V9*

INA181A2QDBVRQ1 SOT95P280X145-6N I ANA 7 1 0 0 0
TIMESTAMP 2026.10.01.08.32.01
"Mouser Part Number" 595-INA181A2QDBVRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/INA181A2QDBVRQ1?qs=9r4v7xj2LnlL1N42dSNUhg%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" INA181A2QDBVRQ1
"Description" AEC-Q100, 26V, bi-directional, low-/high-side, voltage output current sense amplifier
"Datasheet Link" http://www.ti.com/lit/gpn/INA181-Q1
"Geometry.Height" 1.45mm
GATE 1 6 0
INA181A2QDBVRQ1
1 0 U OUT
2 0 U GND
3 0 U IN+
6 0 U VS
5 0 U REF
4 0 U IN-

*END*
*REMARK* SamacSys ECAD Model
2017650/1869991/2.50/6/3/Integrated Circuit
