*PADS-LIBRARY-PART-TYPES-V9*

OPA388QDBVRQ1 SOT95P280X145-5N I ANA 7 1 0 0 0
TIMESTAMP 2026.09.07.12.26.17
"Mouser Part Number" 595-OPA388QDBVRQ1
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/OPA388QDBVRQ1?qs=bAKSY%2FctAC6Sys4JRdGLCQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" OPA388QDBVRQ1
"Description" Operational Amplifiers - Op Amps Automotive qualified, wide bandwidth,zero drift, zero cross over, precision amplifier
"Datasheet Link" https://www.mouser.it/ProductDetail/Texas-Instruments/OPA388QDBVRQ1/?qs=sGAEpiMZZMutXGli8Ay4kImebAOUmgPe3S97szdN%252Bl8%3D
"Geometry.Height" 1.45mm
GATE 1 5 0
OPA388QDBVRQ1
1 0 U OUT
2 0 U V-
3 0 U +IN
4 0 U -IN
5 0 U V+

*END*
*REMARK* SamacSys ECAD Model
12859519/1869991/2.50/5/3/Integrated Circuit
