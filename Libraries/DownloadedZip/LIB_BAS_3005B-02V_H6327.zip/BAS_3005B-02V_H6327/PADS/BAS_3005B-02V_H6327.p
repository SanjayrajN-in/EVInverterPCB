*PADS-LIBRARY-PART-TYPES-V9*

BAS_3005B-02V_H6327 BAS3005B02VH6327 I DIO 7 1 0 0 0
TIMESTAMP 2026.09.24.11.07.33
"Mouser Part Number" 726-BAS3005B02VH6327
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/BAS-3005B-02V-H6327?qs=mzcOS1kGbgd8oDGAc5aqBA%3D%3D
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" BAS 3005B-02V H6327
"Description" Diode Schottky 30V 0.5A 2-Pin SC-79 T/R
"Datasheet Link" https://www.infineon.com/dgdl/Infineon-BAS3005B-DS-v01_01-en.pdf?fileId=db3a30432d9b3066012db880a14b0bc1
"Geometry.Height" 0.59mm
GATE 1 2 0
BAS_3005B-02V_H6327
1 0 U K
2 0 U A

*END*
*REMARK* SamacSys ECAD Model
627329/1869991/2.50/2/3/Schottky Diode
