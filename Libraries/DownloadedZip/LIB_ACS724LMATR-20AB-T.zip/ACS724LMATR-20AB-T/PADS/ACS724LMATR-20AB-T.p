*PADS-LIBRARY-PART-TYPES-V9*

ACS724LMATR-20AB-T SOIC127P1030X265-16N I ANA 7 1 0 0 0
TIMESTAMP 2026.08.07.18.54.49
"Mouser Part Number" 250-724LMATR20ABT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Allegro-MicroSystems/ACS724LMATR-20AB-T?qs=pUKx8fyJudDihMET1LOfaw%3D%3D
"Manufacturer_Name" Allegro Microsystems
"Manufacturer_Part_Number" ACS724LMATR-20AB-T
"Description" High-Accuracy, 5V Isolated Current Sensor with Stray Field Rejection
"Datasheet Link" https://www.allegromicro.com/~/media/Files/Datasheets/ACS724LMA-Datasheet.ashx?la=en&hash=1D95B0F7353C263992ADCE3D7354936355487C8A
"Geometry.Height" 2.65mm
GATE 1 16 0
ACS724LMATR-20AB-T
1 0 U IP+_1
2 0 U IP+_2
3 0 U IP+_3
4 0 U IP+_4
5 0 U IP-_1
6 0 U IP-_2
7 0 U IP-_3
8 0 U IP-_4
16 0 U NC_4
15 0 U GND
14 0 U NC_3
13 0 U FILTER
12 0 U VIOUT
11 0 U NC_2
10 0 U VCC
9 0 U NC_1

*END*
*REMARK* SamacSys ECAD Model
1472909/1869991/2.50/16/2/Integrated Circuit
