*PADS-LIBRARY-PART-TYPES-V9*

MCWI05-12S15 MCWI0512S15 I ANA 9 1 0 0 0
TIMESTAMP 2026.09.30.09.57.39
"Manufacturer_Name" Minmax
"Manufacturer_Part_Number" MCWI05-12S15
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" The MCWI05 series is a range of isolated 5W DC-DC converter modules featuring fully regulated output voltages and ultra-wide 4:1 input voltage ranges. The converters come in a very small SIP-8 package.
"Datasheet Link" https://www.minmaxpower.com/storage/media/Product-MINMAX/MCWI05/Document/MCWI05_Datasheet.pdf
"Geometry.Height" 11.7mm
GATE 1 7 0
MCWI05-12S15
1 0 U -VIN
2 0 U +VIN
3 0 U REMOTE_ON/OFF
5 0 U NC_1
6 0 U +VOUT
7 0 U -VOUT
8 0 U NC_2

*END*
*REMARK* SamacSys ECAD Model
19150636/1869991/2.50/7/2/Power Supply
